const $=id=>document.getElementById(id);
const esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const DAY=864e5,now=Date.now(),iso=d=>new Date(d).toISOString().slice(0,10),today=iso(now);
const ago=t=>{const h=Math.round((Date.now()-t)/36e5);return h<1?'just now':h<48?h+'h ago':Math.round(h/24)+'d ago'};
const money=n=>'KES '+Number(n).toLocaleString('en-US');
const tag=(t,c)=>`<span class="tag ${c||String(t).replace(/\W/g,'')}">${esc(t)}</span>`;
const card=h=>`<div class="card">${h}</div>`;
const btn=(t,f,c)=>`<button class="btn sm ${c||''}" onclick="${f}">${t}</button>`;
const empty=t=>`<div class="empty">${t}</div>`;
const stat=(n,l,c)=>`<div class="card stat"><b class="${c||''}">${n}</b>${l}</div>`;
const bars=rows=>{const mx=Math.max(1,...rows.map(r=>r[1]));return rows.map(([l,v])=>`<div class="bar"><span>${esc(l)}</span><i style="width:${Math.max(3,v/mx*60)}%"></i><b>${v}</b></div>`).join('')};
const toast=m=>{const t=$('toast');t.textContent=m;t.style.display='block';clearTimeout(toast.h);toast.h=setTimeout(()=>t.style.display='none',2800)};

const BUSES=['KAA 101A','KBB 202B','KCC 303C'],SEATS=14,DAYS=[0,1,2].map(i=>iso(now+i*DAY));
const KEY='bs',ROLES=['Passenger','Agent','Driver'],PROFROLE='Driver',PROFLABEL='Your bus',PROF=BUSES;
function seed(){return{routes:[{id:1,from:'Nairobi',to:'Nakuru',fare:800,dep:'07:00',bus:BUSES[0]},{id:2,from:'Nairobi',to:'Kisumu',fare:1500,dep:'08:00',bus:BUSES[1]},{id:3,from:'Nairobi',to:'Mombasa',fare:1600,dep:'20:00',bus:BUSES[2]}],
tix:[{id:1,pax:'Anne Mwikali',phone:'0712000111',rid:1,date:today,seat:3,fare:800,code:'SJ1A2B3C4D',status:'Booked',at:now-DAY},{id:2,pax:'Moses Odhiambo',phone:'0722000222',rid:1,date:today,seat:4,fare:800,code:'SJ5E6F7G8H',status:'Booked',at:now-DAY}],trips:{},notes:[],seq:3}}
const tabs=()=>({Passenger:[['home','Book a seat'],['mine','My tickets']],Agent:[['home','Book a seat'],['mine','Tickets']],Driver:[['home','My trips']],Admin:[['home','Overview'],['routes','Routes and fares'],['mine','All tickets']]}[role]||[]).concat([['alerts','Alerts']]);
let brid=1,bdate=today,sel=0;
const R=id=>S.routes.find(r=>r.id===id),tk=(rid,d)=>S.tix.filter(t=>t.rid===rid&&t.date===d&&t.status!=='Cancelled'),tstat=(rid,d)=>S.trips[rid+'|'+d]||'Scheduled';
function seatGrid(){const taken=tk(brid,bdate).map(t=>t.seat);return `<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-top:8px">${Array.from({length:SEATS},(_,i)=>i+1).map(n=>`<button class="btn sm ${sel===n?'':'ghost'}" style="margin:0;${taken.includes(n)?'opacity:.35':''}" ${taken.includes(n)?'disabled':''} onclick="sel=${n};draw()">${n}</button>`).join('')}</div>`}
function bookView(){const r=R(brid);
 return card(`<b>Book a seat</b><label>Route</label><select onchange="brid=+this.value;sel=0;draw()">${S.routes.map(x=>`<option value="${x.id}" ${x.id===brid?'selected':''}>${x.from} to ${x.to} (${x.dep}) ${money(x.fare)}</option>`).join('')}</select><label>Date</label><select onchange="bdate=this.value;sel=0;draw()">${DAYS.map(d=>`<option ${d===bdate?'selected':''}>${d}</option>`).join('')}</select><div class="sub" style="margin-top:8px">${SEATS-tk(brid,bdate).length} seats free · bus ${r.bus}. Choose a seat:</div>${seatGrid()}`)+
 card(`${role==='Agent'?`<label>Passenger name</label><input id="bn"><label>Phone</label><input id="bp" type="tel">`:''}<label>M-Pesa code for ${money(r.fare)}</label><input id="bc" maxlength="10" placeholder="e.g. SJ1A2B3C4D"><div style="margin-top:12px">${btn('Pay and book seat '+(sel||''),'book()')}</div>`)}
function book(){const r=R(brid),code=$('bc').value.trim().toUpperCase(),pax=role==='Agent'?$('bn').value.trim():me,ph=role==='Agent'?$('bp').value.trim():'';
 if(!sel)return toast('Choose a seat first');if(!pax)return toast('Enter the passenger name');if(!/^[A-Z0-9]{10}$/.test(code))return toast('The M-Pesa code has 10 letters and numbers');
 if(S.tix.some(t=>t.code===code))return toast('That M-Pesa code was already used');if(tk(brid,bdate).some(t=>t.seat===sel))return toast('That seat was just taken');
 const t={id:S.seq++,pax,phone:ph,rid:brid,date:bdate,seat:sel,fare:r.fare,code,status:'Booked',at:Date.now()};S.tix.unshift(t);
 notify(`Ticket SG-${t.id}: ${r.from} to ${r.to}, ${bdate} ${r.dep}, seat ${sel}, bus ${r.bus}.`,pax);notify(`New booking: ${pax}, seat ${sel}, ${bdate}.`,r.bus);sel=0;save();toast('Seat booked. Ticket SG-'+t.id);tab='mine';draw()}
function tcard(t,act){const r=R(t.rid);return card(`<div class="row"><b>SG-${t.id} · seat ${t.seat}</b>${tag(t.status)}</div><div class="sub">${esc(t.pax)} · ${r.from} to ${r.to}<br>${t.date} at ${r.dep} · ${money(t.fare)} · M-Pesa ${esc(t.code)}</div>${act&&t.status==='Booked'&&tstat(t.rid,t.date)==='Scheduled'?`<div style="margin-top:8px">${btn('Cancel ticket','cancelT('+t.id+')','ghost')}</div>`:''}`)}
function cancelT(id){const t=S.tix.find(x=>x.id===id);t.status='Cancelled';notify(`Ticket SG-${id} was cancelled. Refund of ${money(t.fare)} will be sent to your M-Pesa.`,t.pax);save();toast('Ticket cancelled');draw()}
function board(id){S.tix.find(x=>x.id===id).status='Boarded';save();draw()}
function trip(rid,d,s){S.trips[rid+'|'+d]=s;tk(rid,d).forEach(t=>notify(`Your bus ${R(rid).bus} has ${s==='Departed'?'departed':'arrived'}.`,t.pax));save();draw()}
function savePrices(){S.routes.forEach(r=>{const v=+$('f'+r.id).value;if(v>0)r.fare=v});save();toast('Fares updated');draw()}
function overview(){const t=S.tix.filter(x=>x.date===today&&x.status!=='Cancelled');
 return `<div class="grid four">${stat(t.length,'tickets for today')}${stat(money(S.tix.filter(x=>x.status!=='Cancelled').reduce((a,x)=>a+x.fare,0)),'revenue (all booked)','ok')}${stat(S.tix.filter(x=>x.status==='Cancelled').length,'cancelled','bad')}${stat(S.tix.filter(x=>x.status==='Boarded').length,'boarded','info')}</div>
 <div class="card"><b>Seats sold today by route</b>${bars(S.routes.map(r=>[r.from+'-'+r.to,tk(r.id,today).length]))}</div>`}
function view(){
 if(role==='Passenger'||role==='Agent'){if(tab==='mine')return '<h2>Tickets</h2>'+(S.tix.filter(t=>role==='Agent'||t.pax===me).map(t=>tcard(t,1)).join('')||empty('No tickets yet.'));return bookView()}
 if(role==='Driver'){const rs=S.routes.filter(r=>r.bus===prof);return `<div class="sub" style="margin-top:8px">Bus ${esc(prof)}</div>`+DAYS.map(d=>rs.map(r=>{const l=tk(r.id,d),s=tstat(r.id,d);return card(`<div class="row"><b>${r.from} to ${r.to}</b>${tag(s)}</div><div class="sub">${d} at ${r.dep} · ${l.length}/${SEATS} seats</div>${l.map(t=>`<div class="row" style="margin-top:6px"><span>Seat ${t.seat}: ${esc(t.pax)}</span>${t.status==='Boarded'?tag('Boarded'):s==='Scheduled'?btn('Board','board('+t.id+')','ghost'):''}</div>`).join('')}<div style="margin-top:8px">${s==='Scheduled'?btn('Depart','trip('+r.id+',\''+d+'\',\'Departed\')'):s==='Departed'?btn('Arrived','trip('+r.id+',\''+d+'\',\'Arrived\')'):''}</div>`)}).join('')).join('')||empty('No trips for this bus.')}
 if(tab==='routes')return card('<b>Fares (KES)</b>'+S.routes.map(r=>`<label>${r.from} to ${r.to}, ${r.dep}</label><input id="f${r.id}" type="number" min="1" value="${r.fare}">`).join('')+`<div style="margin-top:12px">${btn('Save fares','savePrices()')}</div>`);
 if(tab==='mine')return '<h2>All tickets</h2>'+(S.tix.map(t=>tcard(t,0)).join('')||empty('None.'));
 return overview()}

let S;try{S=JSON.parse(localStorage.getItem(KEY+'_d'))}catch(e){}
if(!S)S=seed();
const save=()=>{try{localStorage.setItem(KEY+'_d',JSON.stringify(S))}catch(e){}};
let tab='home',role='',me='',prof='',mode='login',aerr='';
const key=()=>role==='Admin'?'Admin':(role===PROFROLE&&prof?prof:me);
const notify=(m,who)=>{S.notes.unshift({m,who,at:Date.now(),read:false})};
const mine=()=>S.notes.filter(n=>n.who===key()||n.who==='role:'+role);
const getU=()=>{try{return JSON.parse(localStorage.getItem(KEY+'_users'))||[]}catch(e){return[]}};
const putU=u=>{try{localStorage.setItem(KEY+'_users',JSON.stringify(u))}catch(e){}};
const cur=()=>{try{const e=localStorage.getItem(KEY+'_sess');return getU().find(u=>u.email===e)||null}catch(e){return null}};
async function hash(p,s){const enc=new TextEncoder(),k=await crypto.subtle.importKey('raw',enc.encode(p),'PBKDF2',false,['deriveBits']);
 const b=await crypto.subtle.deriveBits({name:'PBKDF2',salt:enc.encode(s),iterations:100000,hash:'SHA-256'},k,256);
 return Array.from(new Uint8Array(b)).map(x=>x.toString(16).padStart(2,'0')).join('')}
const bad=m=>{aerr=m;const e=$('xerr');if(e)e.textContent=m};
const xrole=()=>{if(PROFROLE)$('xpf').style.display=$('xr').value===PROFROLE?'block':'none'};
function authView(){const reg=mode==='reg';
 return `<div class="card auth"><b>${reg?'Create your account':'Log in'}</b>
 ${reg?`<label>Full name</label><input id="xn" autocomplete="name">`:''}
 <label>Email</label><input id="xe" type="email" autocomplete="email">
 <label>Password</label><input id="xp" type="password" autocomplete="${reg?'new-password':'current-password'}">
 ${reg?`<label>Confirm password</label><input id="xp2" type="password" autocomplete="new-password">
 <label>Account type</label><select id="xr" onchange="xrole()">${ROLES.map(r=>`<option>${r}</option>`).join('')}</select>
 ${PROFROLE?`<div id="xpf" style="display:${ROLES[0]===PROFROLE?'block':'none'}"><label>${PROFLABEL}</label><select id="xl">${PROF.map(p=>`<option>${esc(p)}</option>`).join('')}</select></div>`:''}
 <div class="sub" style="margin-top:8px">The first account created becomes the administrator.</div>`:''}
 <div class="err" id="xerr">${esc(aerr)}</div>
 <div style="margin-top:12px"><button class="btn" onclick="${reg?'doReg()':'doLogin()'}">${reg?'Register':'Log in'}</button></div>
 <div class="sub" style="margin-top:12px">${reg?'Already registered?':'New here?'} <button class="link" onclick="mode='${reg?'login':'reg'}';aerr='';draw()">${reg?'Log in':'Create an account'}</button></div></div>`}
async function doReg(){const n=$('xn').value.trim(),e=$('xe').value.trim().toLowerCase(),p=$('xp').value;
 if(!n)return bad('Enter your full name.');
 if(!/^\S+@\S+\.\S+$/.test(e))return bad('Enter a valid email address.');
 if(p.length<8)return bad('Password must be at least 8 characters.');
 if(p!==$('xp2').value)return bad('Passwords do not match.');
 const us=getU();if(us.some(u=>u.email===e))return bad('That email is already registered. Log in instead.');
 const salt=Array.from(crypto.getRandomValues(new Uint8Array(8))).join('-');
 const r=us.length?$('xr').value:'Admin',pf=(r===PROFROLE)?$('xl').value:'';
 us.push({email:e,name:n,role:r,prof:pf,salt,h:await hash(p,salt)});putU(us);
 try{localStorage.setItem(KEY+'_sess',e)}catch(x){}
 start()}
async function doLogin(){const e=$('xe').value.trim().toLowerCase(),u=getU().find(x=>x.email===e);
 if(!u||u.h!==await hash($('xp').value,u.salt))return bad('Email or password is incorrect.');
 try{localStorage.setItem(KEY+'_sess',e)}catch(x){}
 start()}
function start(){const u=cur();if(!u)return;role=u.role;me=u.name;prof=u.prof||'';tab='home';aerr='';draw()}
function logout(){try{localStorage.removeItem(KEY+'_sess')}catch(e){}mode='login';aerr='';draw()}
function drawNav(){const u=mine().filter(n=>!n.read).length;
 $('nav').innerHTML=tabs().map(([k,l])=>`<button class="${tab===k?'on':''}" onclick="go('${k}')">${l}${k==='alerts'&&u?`<span class="dot">${u}</span>`:''}</button>`).join('')}
const go=k=>{tab=k;draw()};
function alertsView(){const n=mine();n.forEach(x=>x.read=true);save();return n.length?n.map(x=>card(esc(x.m)+`<div class="sub">${ago(x.at)}</div>`)).join(''):empty('No alerts yet.')}
function draw(){const u=cur();$('who').innerHTML=u?`<span>${esc(u.name)} · ${role}</span><button class="btn sm ghost" onclick="logout()">Log out</button>`:'';
 if(!u){$('nav').innerHTML='';$('main').innerHTML=authView();return}
 drawNav();$('main').innerHTML=tab==='alerts'?alertsView():view()}
start();draw();
